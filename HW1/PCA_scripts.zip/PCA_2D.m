% Simple exercise to understand PCA
x=10*rand(100,1);
y=1*rand(100,1);
numlabels=2;

categories = cell(2,1);
categories{1}='large var';
categories{2}='short var';

figure
hold on
plot(x,y,'o');

%%%%% Data Matrix 100 observations 2 variables
figure
M=[x,y]
imagesc(M)
colorbar

%%%%Call PCA
[wcoeff,score,latent,tsquared,explained] = pca(M);
c2=wcoeff(:,1:2)
figure()
plot(score(:,1),score(:,2),'+')
xlabel('1st Principal Component')
ylabel('2nd Principal Component')
figure
biplot(wcoeff(:,1:2),'scores',score(:,1:2),'varlabels',categories);
%axis([-.26 0.6 -.51 .51]);
figure()
pareto(explained)
xlabel('Principal Component')
ylabel('Variance Explained (%)')