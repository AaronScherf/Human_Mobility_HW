%http://www.mathworks.com/help/stats/quality-of-life-in-u-s-cities.html
load cities
categories
%For each category, a higher rating is better. For example, a higher rating for crime means a lower crime rate.
boxplot(ratings,'orientation','horizontal','labels',categories)

%C = corr(ratings,ratings);
w = 1./var(ratings);
[wcoeff,score,latent,tsquared,explained] = pca(ratings,...
'VariableWeights',w);
figure()
plot(score(:,1),score(:,2),'+')
xlabel('1st Principal Component')
ylabel('2nd Principal Component')
coefforth = inv(diag(std(ratings)))*wcoeff;

figure
biplot(coefforth(:,1:2),'scores',score(:,1:2),'varlabels',categories);
%axis([-.26 0.6 -.51 .51]);
figure()
pareto(explained)
xlabel('Principal Component')
ylabel('Variance Explained (%)')
 figure
 biplot(wcoeff(:,1:3),'scores',score(:,1:3),'varlabels',categories);
 figure
 for i=1:size(ratings,1)
     plot(ratings(i,:))
     hold all
 end    