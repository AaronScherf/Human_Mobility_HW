% Simple exercise to understand PCA
x=20*rand(500,1)-10;
y=20*rand(500,1)-10;
z=20*rand(500,1)-10;
%z=sqrt(x.^2+y.^2);

%%%%needed for biplot
numlabels=3;  
categories = cell(3,1);
categories{1}='var 1 ';
categories{2}='var 2';
categories{3}='var 3';

figure
plot(x,y,'o');
hold on
plot(x,z,'x');

%%%%% Data Matrix 10 observations 2 variables
figure
M=[x,y,z]
imagesc(M)
colorbar

%%%%Call PCA
[wcoeff,score,latent,tsquared,explained] = pca(M);
c2=wcoeff(:,1:3)
figure()
plot(score(:,1),score(:,2),'+')
xlabel('1st Principal Component')
ylabel('2nd Principal Component')
figure
biplot(wcoeff(:,1:2),'scores',score(:,1:2),'varlabels',categories);
figure()
pareto(explained)
xlabel('Principal Component')
ylabel('Variance Explained (%)')
figure
 plot3(x,y,z,'o')
 figure
 biplot(wcoeff(:,1:3),'scores',score(:,1:3),'varlabels',categories);
 figure
 for i=1:size(M,1)
     plot(M(i,:))
     hold all
 end  